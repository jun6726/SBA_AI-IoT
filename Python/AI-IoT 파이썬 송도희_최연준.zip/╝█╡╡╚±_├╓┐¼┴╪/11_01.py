def Auth(password):
    count= 0
    FF = 0
    if password.isalpha() or password.isdigit() or len(password)<8:
            if len(password) < 8:
                print("error! 8글자 이상이어야 함:")
            if password.isalpha() :
                print("error! 숫자도 포함되어야 함")
            if password.isdigit():
                print("error! 영문도 포함되어야 함")
            return False

    if password.isalnum():
        for s in password:
            if s.isnumeric():
                count+=1

        if count<2:
            print("error! 최소한 2개의 숫자를 포함해야 함")
            return False

    else:
        print("error! 영문자, 숫자로만 구성되어야 함")
        return False

    return True
"""
    
    if not password.isalnum():
        print("error! 영문자, 숫자로만 구성되어야 함")
        return False
    for s in password:
        if s.isnumeric():
            count+=1
    if count<2:
        print("error! 최소한 2개의 숫자를 포함해야 함")
        return False

    for i in password :
        if i.isdecimal():
             count+= 1
    
    if count < 2 :
        print("error! 최소한 2개의 숫자를 포함해야 함")
        return False

    if FF < 5 :
        return False
    return True"""

for i in range(5):
    password = input("Enter passwod: ")
    if Auth(password) :
        print("Valid password")
        break
    else:
        print("Invalid password")
