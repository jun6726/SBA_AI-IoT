L = list(range(10))

for i in L:
    L[i] = int(input("Enter a number : "))
        
    if(L[i] == 0):
        print("입력 받은 수가 0 입니다.")
        break
        
    if( L[i] < 0 ):
        num_pm = '음수'
    else:
        num_pm = '양수'
         
    if(L[i] % 2 == 0):
        num_eo = '짝수'
    else:
        num_eo = '홀수'
            
    print("%d : %s, %s " %(L[i], num_pm, num_eo))
print("프로그램을 종료합니다")
