L = list(range(2,100,2))

for i in L:
    if(i % 8 == 0):
        print("%d" %i, end = " ")
