import random as rand

def coin(coinPercent) :
    P = rand.randint(0,1)
    if P == 0:
        coinPercent += 1
    return coinPercent


count = 1
coinPercent= 0

x = int(input("동전 던지기 시도 횟수를 입력(1-100) : "))


for i in range(x):
    coinPercent = coin(coinPercent)
    if (count < 10 or count s% 10 ==0):
        print("{}번째까지 던지기에서 앞면이 나온 확률 : {:2d}%".format(count, int((coinPercent/count)*100 )))
    count += 1

print("*"*30)

print("총 {}번 동전 던지기에서 앞면이 나올 확률 : {:2d}%".format(x, int((coinPercent/x)*100)))

