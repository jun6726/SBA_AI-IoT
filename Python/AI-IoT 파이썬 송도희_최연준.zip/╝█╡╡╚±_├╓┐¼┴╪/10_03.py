evenCount = 0
oddCount = 0
sumNum = 0
i =0

data = [int(x) for x in input("정수들을 입력 : \n").split()]
dataNum = len(data)

if dataNum == 0 :
    print("입력한 숫자가 없습니다")
else :
    while(dataNum > 0):
        if(data[dataNum-1] > 0):
            evenCount += 1
        else:
            oddCount += 1

        sumNum += 1
        dataNum = dataNum - 1
        
print("양수 : %d 개, 음수 : %d 개, 합계 : %d" %(evenCount, oddCount, sumNum))
