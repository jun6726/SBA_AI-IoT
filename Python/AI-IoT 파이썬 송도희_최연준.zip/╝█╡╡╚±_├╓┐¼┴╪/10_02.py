x = int(input("구하려는 소수의 개수를 입력 : "))
num = 2
num_n = 1
sosu = 0 

def isPrime(num):
    for i in range(2, num):
        if (num % i == 0):
            return 0
    return 1

while(True):
    num_n += 1
    if isPrime(num_n) :
            print(num_n)
            sosu += 1
    if (sosu == x):
        break
        
print("%d 개의 소수를 찾았습니다" %x)
 
