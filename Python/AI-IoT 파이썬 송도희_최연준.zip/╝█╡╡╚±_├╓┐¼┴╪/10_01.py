i = 0
sumL = 0
numList =[]
    
while(True):
    L = int(input("정수를 입력 (0을 입력하면 종료) : "))
    if (L == 0):
        break

    numList.append(L)
    sumL = sumL + L
    i = i+1
    avgL = sumL / i

print("입력한 정수 리스트 : ", numList)
print("합계 : %d" %sumL)
print("평균 : %0.2f" %avgL)

