L = open("L_In.txt",'r')
D = open("L_Out.txt",'w')

index = int(L.readline())
A=list(int(x) for x in L.readline().split())
B=list(int(x) for x in L.readline().split())

result= A[index]+B[index]
print("index = %d" %index, file=D)
print("A = ",A, file =D)
print("B = ", B, file=D)
print("A[%d]+ B[%d] = %d" %(index,index, result), file=D)

L.close(); D.close()
'''
for s in L:
    num = L.readlines()
    num = list(int(x) for x in s.split())

    for i in range(len(num)):
        if(num[i] == num[0]):
            print("index = ", num[0], file = D)
        elif(num[i] == num[1]):
            print("A = ", num[1], file = D)
        else:
            print("B = ", num[2], file = D)
L.close(); D.close()

#print("A[2] + B[2] = %d" %(num[1][2]+num[2][2]), file = D)
'''
