def F1 (x1,x2):
    return x1 * x2

def F2 (x1,x2):
    return x1 / x2

def F3 (x1,x2):
    return x1 + x2

def F4 (x1,x2):
    return x1 - x2

x = input("수식 입력(예: 20 * 40)")
x1, x2, x3 = x.split()
x1 = float(x1)
x3 = float(x3)

if(x2 == '*'):
    result = F1(x1,x3)
elif(x2 == '/'):
    if(x3==0):
        print("0.000000 로 나누기를 수행할 수 없습니다")
    else:
        result = F2(x1,x3)
elif(x2 == '+'):
    result = F3(x1,x3)
elif(x2 == '-'):
    result = F4(x1,x3)
if(x3!=0):
    print("%f %s %f = %f" %(x1,x2,x3,result))
