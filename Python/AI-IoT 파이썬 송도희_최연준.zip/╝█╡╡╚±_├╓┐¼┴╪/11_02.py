str_in = input("문자열 입력 : ").lower()

def str_input(x):
    D = {}
    for c in x:
        if c.isspace():
            continue
        D[c] = D.get(c,0)+1
    return D
        
output = str_input(str_in)

for i in output :
    print("%s : %d" %(i,output[i]))

