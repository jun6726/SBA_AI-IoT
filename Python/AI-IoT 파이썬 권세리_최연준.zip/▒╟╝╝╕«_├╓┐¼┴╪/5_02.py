str1 = "Good words cost nothing"
word = input("찾는 단어 입력 : ")
find_word = str1.count(word)

print("%s 문장에서는 %s 단어가 %d 번 있습니다." %(str1, word, find_word))
