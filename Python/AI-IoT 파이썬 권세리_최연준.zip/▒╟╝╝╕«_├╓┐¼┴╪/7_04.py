'''4. 사용자로부터 숫자 월을 입력받아 그것에 대한 영문 이름을
출력하는 코드를 작성하시오.
- 2가지 버전으로 코드를 작성한다.
리스트 없이, if조건문을 사용하여 작성하시오.
if조건문 없이, 리스트를 사용하여 작성하시오. '''

print("***** if조건문으로 작성 *****")
input_month = int(input("월을 입력하세요: "))
if(input_month == 1):
    result_month = "Jan"
elif(input_month == 2):
    result_month = "Fab"
elif(input_month == 3):
    result_month = "Mar"
elif(input_month == 4):
    result_month = "Apl"
elif(input_month == 5):
    result_month = "May"
elif(input_month == 6):
    result_month = "June"
elif(input_month == 7):
    result_month = "July"
elif(input_month == 8):
    result_month = "Aug"
elif(input_month == 9):
    result_month = "Sep"
elif(input_month == 10):
    result_month = "Oct"
elif(input_month == 11):
    result_month = "Nov"
elif(input_month == 12):
    result_month = "Dec"
print("%d월은 %s입니다" %(input_month, result_month))
print("***** 리스트로 작성 *****")
input_month2 = int(input("월을 입력하세요: "))
L = ["Jan","Fab", "Mar", "Apl","May", "June", "July", "Aug", "Sep", "Oct", "Nov", "Dec"]
L_num = list(enumerate(L))
print("%d월은 %s입니다" %(input_month2, L_num[input_month2-1][1]))
