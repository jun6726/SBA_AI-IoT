fruit = {'배': [2, 1000], '자몽' : [1, 2000], '메론' : [1, 8000], '감' : [6, 800]}

want = input("먹고싶은 과일은?:")


if(fruit.get(want,0)):
    print(want, "맛있게 드세요.")
    fruit[want][0] -= 1
else:
    print(want, "준비되어 있지 않습니다.")

price = 0

if(fruit["배"][0] < 5):
    price += (5-fruit["배"][0])*fruit["배"][1]
if(fruit["자몽"][0] < 5):
    price += (5-fruit["자몽"][0])*fruit["자몽"][1]
if(fruit["메론"][0] < 5):
    price += (5-fruit["메론"][0])*fruit["메론"][1]
if(fruit["감"][0] < 5):
    price += (5-fruit["감"][0])*fruit["감"][1]


print("각 과일 달 최소 5개는 되도록 구입합니다.")
print("구입에 필요한 총 금액은 : %d 원 입니다." %price)
