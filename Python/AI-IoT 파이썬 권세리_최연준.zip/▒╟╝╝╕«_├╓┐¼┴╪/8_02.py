D = {'c':7 , 'f':3, 'a':5}

print("After sort : ", sorted(D.items()))
