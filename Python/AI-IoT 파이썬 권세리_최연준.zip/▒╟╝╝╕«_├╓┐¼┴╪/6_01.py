"""1. 세 개의 정수를 입력 받아 내림차순으로 정렬하여 출력하는 script 작성
(한번의 입력 함수만 사용)"""

x = input("세 개의 정수를 입력하시오 : ")
x1,x2,x3 = x.split()
x1,x2,x3 = int(x1),int(x2),int(x3)

if(x1 > x2):
    if(x2 > x3):
        print(x1,x2,x3)
    else:
        print(x1,x3,x2)
elif(x2 > x3):
    if(x3 > x1):
        print(x2,x3,x1)
    else:
        print(x2,x1,x3)
elif(x3 > x1):
    if(x1 > x2):
        print(x3,x1,x2)
    else:
        print(x3,x2,x1)

