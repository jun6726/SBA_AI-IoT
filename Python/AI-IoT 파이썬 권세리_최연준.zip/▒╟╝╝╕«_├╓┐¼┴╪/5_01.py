x = input("정수 숫자 3개를 입력 ")
x1, x2, x3 = x.split()
print("입력 받은 값 : %s %s %s" %(x1,x2,x3))
sum_x = int(x1) + int(x2) + int(x3)
avg_x = sum_x / 3.0


print("총합 : %d" %(sum_x))
print("평균 : %.1f" %(avg_x))
