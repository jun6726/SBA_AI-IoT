import math

input_num = input("두 점의 좌표값을 x1, y1, x2, y2 순서대로 입력 : ")
x1, y1, x2, y2 = input_num.split()
x1, y1, x2, y2 = int(x1) , int(y1), int(x2), int(y2)

d1 = math.sqrt((x2-x1)**2 + (y2-y1)**2)

print("두 점 사이의 거리는 %d 입니다" %d1)
print("두 점 사이의 거리는 5이하 입니까?", d1 <= 5)
