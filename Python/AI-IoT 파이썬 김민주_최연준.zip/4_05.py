num = 3.1415926; x = "123"; y ="abc"

print("{}, {}, {}".format(x[2:3], x[:1], x[1:2]))
print("        {:10.2f}".format(num))
print("       {:10d}".format(int(x)))
print("{}".format(y))
