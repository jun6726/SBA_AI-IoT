sample = "abcABCdEFaBCDeFAbC"
abc_count = sample.lower().count("abc")
abc_index = sample.lower().find("abc")
def_count = sample.lower().count("def")
def_index = sample.lower().find("def")

print("abc 문자열 : %d 인덱스, %d 번 존재" %(abc_index,abc_count))
print("def 문자열 : %d 인덱스, %d 번 존재" %(def_index,def_count))
