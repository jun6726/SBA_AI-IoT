import math

x = 10
sen ='\n'
print(x, type(x), sen)

print("5의 루트 값은:  ", round(math.sqrt(5), 5), sen)

s1 = 'hello'

print(s1[::2])
print(s1[::-1])
print(s1[1::-1])
print(s1[2:5], sen)

korean = 80.30
english = 95.70
math = 73.20
sum_kem = 0.0
avg = 0.0

print("과목    점수")
print("------------")
print("국어:  ",korean)
print("영어:  ",english)
print("수학:  ",math)

sum_kem = korean + english + math
avg = round(sum_kem / 3, 4)

print("총점: ",sum_kem)
print("평균:  ",avg, sen)

str1 ='These_functions_cannot_be_used_with_complex_numbers.'
print("원래 문장: ",str1)
re_str = str1.replace("_", " ")
print("수정한 문장: ",re_str)
a_count = re_str.count('a')
e_count = re_str.count('e')
u_count = re_str.count('u')
space_count = re_str.count(" ")
print("%s는 %d번 나왔다." %("a",a_count))
print("%s는 %d번 나왔다." %("e",e_count))
print("%s는 %d번 나왔다." %("u",u_count))
print("%s는 %d번 나왔다." %("space",space_count))
upper_str1 = re_str.upper()
print("모두 대문자로 바꾸면: %s" %upper_str1)
