original = "This class is Computational Thinking!"

print("reversed sentence : {}".format(original[::-1]) );
