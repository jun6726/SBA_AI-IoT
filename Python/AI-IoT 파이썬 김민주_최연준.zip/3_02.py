money = 3928
coin_500 = 0
coin_100 = 0
coin_amount = 0                

coin_500 = money // 500
print("500원짜리 동전 : ",coin_500, "개")

coin_100 = (money % 500) // 100
print("100원짜리 동전 : ", coin_100, "개")

coin_amount = (money % 500) % 100
print("남은 금액 : ", coin_amount, "원")
