print("python script test")
print((4*2) - 1.5)
3*7
print(9 // 4)
print(9 % 4)
x = 4
y = 9
print("x =",x , 'y =',y)
print(x * y - x / y)
