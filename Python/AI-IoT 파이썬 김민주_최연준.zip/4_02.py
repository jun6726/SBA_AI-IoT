s1 = "Sogang University"
s2 = s1[:6]
s3 = s1[7:17]
s4 = s1[5::-1]
print("s1은", s1)
print("s2는", s2)
print("s3은", s3)
print("s4는", s4)
