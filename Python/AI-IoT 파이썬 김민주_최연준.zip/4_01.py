str1="Computer 4"; str2 ="Science#5"

print(str1[:8] * int(str1[9:]))
print(str2[:7] * int(str2[8:]))
