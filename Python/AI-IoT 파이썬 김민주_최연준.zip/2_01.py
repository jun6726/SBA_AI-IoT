x = 3.14

x = str(x)
print(x, type(x))

x = int(float(x))
print(x, type(x))

x = float(x)
print(x, type(x))
