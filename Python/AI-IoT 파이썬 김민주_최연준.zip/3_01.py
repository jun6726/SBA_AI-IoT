import math
a = 21.9
b = 37
c = 13.6
avg = (a+b+c) / 3

print("average : ", math.trunc(avg))
