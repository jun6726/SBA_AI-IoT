#내장 모듈
from urllib.request import *
import sys
import time

#외부 모듈
from bs4 import *
import matplotlib.pyplot as p

def extractLastPrice ( webUrl ) :  
    pList = list()
    
    wPage = urlopen(webUrl)
    soup = BeautifulSoup(wPage, 'html.parser')

    for i in range(24):
        trList = soup.find('table',attrs={'class' :'table_midterm'})
        tbody = trList.find('tbody')
        tb = tbody.find('tr')
        
        li = tb.find_all('li')
        li_de = li[1]

        if(i%2==1):
            pList.append(int(li[i].get_text().replace("%","")))
            
    return pList

def inputCompanyAndDays ():
    print ('1:서울/경기도, 2:강원도, 3:충남/충북, 4:전남/전북, 5:경남/경북, 6:제주')
    inputName = input ('지역을 고르세요 : ')
    inputCity = 0
    if (inputName == '1'):
        webUrl = 'http://www.weather.go.kr/weather/forecast/mid-term_02.jsp'
        count = 1
    elif (inputName == '2'):
        webUrl = 'http://www.weather.go.kr/weather/forecast/mid-term_03.jsp'
        count = 2
        city1 = '영서'; city2 = '영동'
    elif (inputName == '3'):
        webUrl = 'http://www.weather.go.kr/weather/forecast/mid-term_04.jsp'
        count = 2
        city1 = '대전, 세종, 충남'; city2 = '충북'
    elif (inputName == '4'):
        webUrl = 'http://www.weather.go.kr/weather/forecast/mid-term_05.jsp'
        count = 2
        city1 = '광주, 전남'; city2 = '전북'
    elif (inputName == '5'):
        webUrl = 'http://www.weather.go.kr/weather/forecast/mid-term_06.jsp'
        count = 2
        city1 = '부산, 울산, 경남'; city2 = '대구, 경북'
    elif (inputName == '6'):
        webUrl = 'http://www.weather.go.kr/weather/forecast/mid-term_07.jsp'
        count = 1
    else:
        print("잘못된 입력입니다. 프로그램을 종료합니다.")
        sys.exit()

    if(count == 2) :
        #원하는 지역의 날씨를 입력받습니다.
        inputCity = int(input ('원하는 지역의 날씨를 입력해주세요 %s, %s : ' %(city1, city2)))
        if (inputCity > 0) :
            inputCity = int (inputCity)
        else:
            print("잘못된 입력입니다. 프로그램을 종료합니다.")
            sys.exit()

    return  webUrl

    
def drawGraph (pList):
    
    
    x = ['M.AM', 'M.PM', 'T.AM', 'T.PM', 'W.AM', 'W.PM', 'T.AM', 'T.PM', 'F.AM', 'F.PM','Sat', 'Sun']
    y = [range(len(pList))]

    p.bar(x, pList)
    p.xlabel("day")
    p.ylabel("%")
    p.title("Precipitation")
    p.show()


webUrl = inputCompanyAndDays() # 도시 선택

pList = extractLastPrice(webUrl) # 종가 추출

drawGraph(pList) # 그리기
